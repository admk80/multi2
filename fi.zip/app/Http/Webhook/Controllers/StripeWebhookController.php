<?php

namespace CreatyDev\Http\Webhook\Controllers;

use Illuminate\Http\Request;
use Laravel\Cashier\Http\Controllers\WebhookController;
use CreatyDev\App\Controllers\Controller;

class StripeWebhookController extends WebhookController
{
    //
}
