<?php

namespace CreatyDev\Domain;

use Illuminate\Database\Eloquent\Model;

class Prices extends Model
{
    //
}
