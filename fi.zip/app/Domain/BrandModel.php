<?php

namespace CreatyDev\Domain;

use Illuminate\Database\Eloquent\Model;

class BrandModel extends Model
{
    //
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'brands';
}
